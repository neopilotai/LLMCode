import java.util.List;

class Series {
    Series(String string) {
        throw new UnsupportedOperationException("Please implement the Series(string) constructor.");
    }

    List<String> slices(int num) {
        throw new UnsupportedOperationException("Please implement the Series.slices() method.");
    }
}
