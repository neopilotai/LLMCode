import java.util.List;

class Dominoes {

    List<Domino> formChain(List<Domino> inputDominoes) throws ChainNotFoundException {
        throw new UnsupportedOperationException("Delete this statement and write your own implementation.");
    }

}