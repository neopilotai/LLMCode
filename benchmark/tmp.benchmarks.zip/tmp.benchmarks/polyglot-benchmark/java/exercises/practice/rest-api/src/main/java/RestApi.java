import org.json.JSONObject;

class RestApi {

    RestApi(User... users) {
        throw new UnsupportedOperationException("Delete this statement and write your own implementation.");
    }

    String get(String url) {
        throw new UnsupportedOperationException("Delete this statement and write your own implementation.");
    }

    String get(String url, JSONObject payload) {
        throw new UnsupportedOperationException("Delete this statement and write your own implementation.");
    }

    String post(String url, JSONObject payload) {
        throw new UnsupportedOperationException("Delete this statement and write your own implementation.");
    }

}