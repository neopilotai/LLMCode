class InvalidRecordsException extends Exception {

    InvalidRecordsException(String message) {
        super(message);
    }
}
