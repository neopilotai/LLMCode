import java.util.List;

class ChangeCalculator {

    ChangeCalculator(List<Integer> currencyCoins) {
        throw new UnsupportedOperationException("Delete this statement and write your own implementation.");
    }

    List<Integer> computeMostEfficientChange(int grandTotal) {
        throw new UnsupportedOperationException("Delete this statement and write your own implementation.");
    }

}
