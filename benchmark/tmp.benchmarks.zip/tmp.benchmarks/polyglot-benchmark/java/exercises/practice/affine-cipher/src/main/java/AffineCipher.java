public class AffineCipher {
    
    public String encode(String text, int coefficient1, int coefficient2){
        throw new UnsupportedOperationException("Please implement AffineCipher.encode() method.");
    }

    public String decode(String text, int coefficient1, int coefficient2){
        throw new UnsupportedOperationException("Please implement AffineCipher.decode() method.");
    }
}