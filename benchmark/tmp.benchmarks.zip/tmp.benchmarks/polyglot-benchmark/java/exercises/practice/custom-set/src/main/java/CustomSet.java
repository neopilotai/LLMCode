import java.util.Collection;

class CustomSet<T> {
    CustomSet() {
        throw new UnsupportedOperationException("Delete this statement and write your own implementation.");
    }

    CustomSet(Collection<T> data) {
        throw new UnsupportedOperationException("Delete this statement and write your own implementation.");
    }

    boolean isEmpty() {
        throw new UnsupportedOperationException("Delete this statement and write your own implementation.");
    }

    boolean contains(T element) {
        throw new UnsupportedOperationException("Delete this statement and write your own implementation.");
    }

    boolean isDisjoint(CustomSet<T> other) {
        throw new UnsupportedOperationException("Delete this statement and write your own implementation.");
    }

    boolean add(T element) {
        throw new UnsupportedOperationException("Delete this statement and write your own implementation.");
    }

    @Override
    public boolean equals(Object obj) {
        throw new UnsupportedOperationException("Delete this statement and write your own implementation.");
    }

    CustomSet<T> getIntersection(CustomSet<T> other) {
        throw new UnsupportedOperationException("Delete this statement and write your own implementation.");
    }

    CustomSet<T> getUnion(CustomSet<T> other) {
        throw new UnsupportedOperationException("Delete this statement and write your own implementation.");
    }

    CustomSet<T> getDifference(CustomSet<T> other) {
        throw new UnsupportedOperationException("Delete this statement and write your own implementation.");
    }

    boolean isSubset(CustomSet<T> other) {
        throw new UnsupportedOperationException("Delete this statement and write your own implementation.");
    }
}
