public class BankAccountActionInvalidException extends Exception {

    public BankAccountActionInvalidException(String message) {
        super(message);
    }
}
