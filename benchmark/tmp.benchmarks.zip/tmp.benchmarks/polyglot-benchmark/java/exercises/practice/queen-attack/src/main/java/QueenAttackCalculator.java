class QueenAttackCalculator {

    QueenAttackCalculator(Queen queen1, Queen queen2) {
        throw new UnsupportedOperationException("Delete this statement and write your own implementation.");
    }

    boolean canQueensAttackOneAnother() {
        throw new UnsupportedOperationException("Delete this statement and write your own implementation.");
    }

}