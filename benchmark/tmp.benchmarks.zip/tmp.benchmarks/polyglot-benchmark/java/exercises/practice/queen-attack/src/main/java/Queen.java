class Queen {

    Queen(int row, int column) {
        throw new UnsupportedOperationException("Delete this statement and write your own implementation.");
    }

}
