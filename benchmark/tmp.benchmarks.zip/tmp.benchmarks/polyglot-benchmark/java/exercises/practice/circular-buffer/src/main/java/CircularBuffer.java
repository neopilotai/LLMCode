class CircularBuffer<T> {

    CircularBuffer(final int size) {
        throw new UnsupportedOperationException("Delete this statement and write your own implementation.");
    }

    T read() throws BufferIOException {
        throw new UnsupportedOperationException("Delete this statement and write your own implementation.");
    }

    void write(T data) throws BufferIOException {
        throw new UnsupportedOperationException("Delete this statement and write your own implementation.");
    }

    void overwrite(T data) {
        throw new UnsupportedOperationException("Delete this statement and write your own implementation.");
    }

    void clear() {
        throw new UnsupportedOperationException("Delete this statement and write your own implementation.");
    }

}