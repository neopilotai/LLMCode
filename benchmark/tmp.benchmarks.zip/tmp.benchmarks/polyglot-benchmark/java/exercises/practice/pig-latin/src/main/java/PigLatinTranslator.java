class PigLatinTranslator {
    public String translate(String word) {
        throw new UnsupportedOperationException("Please implement the translate() method");
    }

}