class UnsolvablePuzzleException extends Exception {
}
