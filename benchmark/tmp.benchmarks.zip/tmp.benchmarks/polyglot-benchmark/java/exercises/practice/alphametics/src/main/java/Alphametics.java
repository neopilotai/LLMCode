import java.util.Map;

class Alphametics {

    Alphametics(String userInput) {
        throw new UnsupportedOperationException("Delete this statement and write your own implementation.");
    }

    Map<Character, Integer> solve() throws UnsolvablePuzzleException {
        throw new UnsupportedOperationException("Delete this statement and write your own implementation.");
    }

}