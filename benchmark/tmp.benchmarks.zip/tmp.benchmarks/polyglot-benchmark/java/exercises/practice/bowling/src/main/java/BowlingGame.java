class BowlingGame {

    void roll(int pins) {
        throw new UnsupportedOperationException("Delete this statement and write your own implementation.");
    }

    int score() {
        throw new UnsupportedOperationException("Delete this statement and write your own implementation.");
    }

}