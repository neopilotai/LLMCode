# Introduction

You've just been hired as professor of mathematics.
Your first week went well, but something is off in your second week.
The problem is that every answer given by your students is wrong!
Luckily, your math skills have allowed you to identify the problem: the student answers _are_ correct, but they're all in base 2 (binary)!
Amazingly, it turns out that each week, the students use a different base.
To help you quickly verify the student answers, you'll be building a tool to translate between bases.
