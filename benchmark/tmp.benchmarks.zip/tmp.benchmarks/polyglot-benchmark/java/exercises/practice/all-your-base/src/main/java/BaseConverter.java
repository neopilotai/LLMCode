class BaseConverter {

    BaseConverter(int originalBase, int[] originalDigits) {
        throw new UnsupportedOperationException("Delete this statement and write your own implementation.");
    }

    int[] convertToBase(int newBase) {
        throw new UnsupportedOperationException("Delete this statement and write your own implementation.");
    }

}