public class Transpose {
    public String transpose(String toTranspose) {
        throw new UnsupportedOperationException("Please implement the Transpose.transpose() method.");
    }
}
