import java.util.List;

class ProteinTranslator {

    List<String> translate(String rnaSequence) {
        throw new UnsupportedOperationException("Delete this statement and write your own implementation.");
    }
}
