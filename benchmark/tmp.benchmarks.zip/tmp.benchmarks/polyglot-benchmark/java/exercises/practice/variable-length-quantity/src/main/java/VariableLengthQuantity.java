import java.util.List;

class VariableLengthQuantity {

    List<String> encode(List<Long> numbers) {
        throw new UnsupportedOperationException("Delete this statement and write your own implementation.");
    }

    List<String> decode(List<Long> bytes) {
        throw new UnsupportedOperationException("Delete this statement and write your own implementation.");
    }
}
