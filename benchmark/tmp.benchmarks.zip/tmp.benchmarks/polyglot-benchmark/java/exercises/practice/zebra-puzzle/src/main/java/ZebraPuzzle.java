class ZebraPuzzle {
    String getWaterDrinker() {
        throw new UnsupportedOperationException("Please implement the ZebraPuzzle.getWaterDrinker() method.");
    }

    String getZebraOwner() {
        throw new UnsupportedOperationException("Please implement the ZebraPuzzle.getZebraOwner() method.");
    }
}
