class TwoBucket {
    TwoBucket(int bucketOneCap, int bucketTwoCap, int desiredLiters, String startBucket) {
        throw new UnsupportedOperationException("Please implement the TwoBucket(int, int, int, String) constructor.");
    }

    int getTotalMoves() {
        throw new UnsupportedOperationException("Please implement the TwoBucket.getTotalMoves() method.");
    }

    String getFinalBucket() {
        throw new UnsupportedOperationException("Please implement the TwoBucket.getFinalBucket() method.");
    }

    int getOtherBucket() {
        throw new UnsupportedOperationException("Please implement the TwoBucket.getOtherBucket() method.");
    }
}
