import java.util.List;

class KindergartenGarden {

    KindergartenGarden(String garden) {
        throw new UnsupportedOperationException("Delete this statement and write your own implementation.");
    }

    List<Plant> getPlantsOfStudent(String student) {
        throw new UnsupportedOperationException("Delete this statement and write your own implementation.");
    }

}
