# Introduction

The kindergarten class is learning about growing plants.
The teacher thought it would be a good idea to give the class seeds to plant and grow in the dirt.
To this end, the children have put little cups along the window sills and planted one type of plant in each cup.
The children got to pick their favorites from four available types of seeds: grass, clover, radishes, and violets.
