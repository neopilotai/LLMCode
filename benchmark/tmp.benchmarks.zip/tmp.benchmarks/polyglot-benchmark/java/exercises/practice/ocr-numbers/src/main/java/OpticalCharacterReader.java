import java.util.List;

class OpticalCharacterReader {

    String parse(List<String> input) {
        throw new UnsupportedOperationException("Delete this statement and write your own implementation.");
    }

}