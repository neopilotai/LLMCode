class PhoneNumber {

    PhoneNumber(String numberString) {
        throw new UnsupportedOperationException("Delete this statement and write your own implementation.");
    }

    String getNumber() {
        throw new UnsupportedOperationException("Delete this statement and write your own implementation.");
    }

}