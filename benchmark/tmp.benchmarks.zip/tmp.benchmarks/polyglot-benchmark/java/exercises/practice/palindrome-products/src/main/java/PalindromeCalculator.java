import java.util.List;
import java.util.SortedMap;

class PalindromeCalculator {

    SortedMap<Long, List<List<Integer>>> getPalindromeProductsWithFactors(int minFactor, int maxFactor) {
        throw new UnsupportedOperationException("Delete this statement and write your own implementation.");
    }

}