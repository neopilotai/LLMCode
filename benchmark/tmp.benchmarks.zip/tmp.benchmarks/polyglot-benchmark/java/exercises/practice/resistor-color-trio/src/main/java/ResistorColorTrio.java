class ResistorColorTrio {
    String label(String[] colors) {
        throw new UnsupportedOperationException("Delete this statement and write your own implementation.");
    }
}
