public class MazeGenerator {

    public char[][] generatePerfectMaze(int rows, int columns) {
        throw new UnsupportedOperationException("Delete this statement and write your own implementation.");
    }

    public char[][] generatePerfectMaze(int rows, int columns, int seed) {
        throw new UnsupportedOperationException("Delete this statement and write your own implementation.");
    }
}
