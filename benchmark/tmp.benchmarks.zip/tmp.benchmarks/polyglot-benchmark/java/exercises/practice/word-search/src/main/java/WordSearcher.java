import java.util.Map;
import java.util.Optional;
import java.util.Set;

class WordSearcher {
    Map<String, Optional<WordLocation>> search(final Set<String> words, final char[][] grid) {
        throw new UnsupportedOperationException("Please implement the WordSearcher.search() method.");
    }
}
