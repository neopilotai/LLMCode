class BottleSong {

    String recite(int startBottles, int takeDown) {
        throw new UnsupportedOperationException("Delete this statement and write your own implementation.");
    }

}