enum GameState {
    WIN,
    DRAW,
    ONGOING
}
