import java.util.List;

class PythagoreanTriplet {

    PythagoreanTriplet(int a, int b, int c) {
        throw new UnsupportedOperationException("Delete this statement and write your own implementation.");
    }

    static TripletListBuilder makeTripletsList() {
        throw new UnsupportedOperationException("Delete this statement and write your own implementation.");
    }

    static class TripletListBuilder {

        TripletListBuilder thatSumTo(int sum) {
            throw new UnsupportedOperationException("Delete this statement and write your own implementation.");
        }

        TripletListBuilder withFactorsLessThanOrEqualTo(int maxFactor) {
            throw new UnsupportedOperationException("Delete this statement and write your own implementation.");
        }

        List<PythagoreanTriplet> build() {
            throw new UnsupportedOperationException("Delete this statement and write your own implementation.");
        }

    }

}