class WordProblemSolver {
    int solve(final String wordProblem) {
        throw new UnsupportedOperationException("Please implement the WordProblemSolver.solve() method.");
    }
}
