import java.util.List;

class Poker {

    Poker(List<String> hand) {
        throw new UnsupportedOperationException("Delete this statement and write your own implementation.");
    }

    List<String> getBestHands() {
        throw new UnsupportedOperationException("Delete this statement and write your own implementation.");
    }

}