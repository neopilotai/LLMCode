import io.reactivex.Observable;

class Hangman {

    Observable<Output> play(Observable<String> words, Observable<String> letters) {
        throw new UnsupportedOperationException("Delete this statement and write your own implementation.");
    }

}