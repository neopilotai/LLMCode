enum Status {
    PLAYING,
    WIN,
    LOSS
}
