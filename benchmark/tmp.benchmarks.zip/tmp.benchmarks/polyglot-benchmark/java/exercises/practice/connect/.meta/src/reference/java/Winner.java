enum Winner {
    PLAYER_O,
    PLAYER_X,
    NONE
}
