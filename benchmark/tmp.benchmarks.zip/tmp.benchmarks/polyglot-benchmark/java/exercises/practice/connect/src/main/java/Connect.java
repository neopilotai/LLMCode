class Connect {

    public Connect(String[] board) {
        throw new UnsupportedOperationException("Implement this function");
    }

    public Winner computeWinner() {
        throw new UnsupportedOperationException("Implement this function");
    }
}
