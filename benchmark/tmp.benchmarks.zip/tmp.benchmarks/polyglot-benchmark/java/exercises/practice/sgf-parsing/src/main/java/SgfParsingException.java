public class SgfParsingException extends Exception {

    public SgfParsingException(String message) {
        super(message);
    }

}
