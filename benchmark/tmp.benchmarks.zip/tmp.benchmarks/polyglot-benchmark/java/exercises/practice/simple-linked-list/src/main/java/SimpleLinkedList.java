class SimpleLinkedList<T> {
    SimpleLinkedList() {
        throw new UnsupportedOperationException("Please implement the SimpleLinkedList() constructor.");
    }

    SimpleLinkedList(T[] values) {
        throw new UnsupportedOperationException("Please implement the SimpleLinkedList(T[]) constructor.");
    }

    void push(T value) {
        throw new UnsupportedOperationException("Please implement the SimpleLinkedList.push() method.");
    }

    T pop() {
        throw new UnsupportedOperationException("Please implement the SimpleLinkedList.pop() method.");
    }

    void reverse() {
        throw new UnsupportedOperationException("Please implement the SimpleLinkedList.reverse() method.");
    }

    T[] asArray(Class<T> clazz) {
        throw new UnsupportedOperationException("Please implement the SimpleLinkedList.asArray() method.");
    }

    int size() {
        throw new UnsupportedOperationException("Please implement the SimpleLinkedList.size() method.");
    }
}
