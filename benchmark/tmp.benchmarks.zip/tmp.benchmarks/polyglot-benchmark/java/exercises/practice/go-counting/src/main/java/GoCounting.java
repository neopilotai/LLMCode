import java.awt.Point;
import java.util.Map;
import java.util.Set;

class GoCounting {

    GoCounting(String board) {
        throw new UnsupportedOperationException("Delete this statement and write your own implementation.");
    }

    Player getTerritoryOwner(int x, int y) {
        throw new UnsupportedOperationException("Delete this statement and write your own implementation.");
    }

    Set<Point> getTerritory(int x, int y) {
        throw new UnsupportedOperationException("Delete this statement and write your own implementation.");
    }

    Map<Player, Set<Point>> getTerritories() {
        throw new UnsupportedOperationException("Delete this statement and write your own implementation.");
    }

}