enum Player {
    NONE, BLACK, WHITE
}
