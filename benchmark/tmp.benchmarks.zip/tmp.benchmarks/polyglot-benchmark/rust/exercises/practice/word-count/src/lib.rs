use std::collections::HashMap;

/// Count occurrences of words.
pub fn word_count(words: &str) -> HashMap<String, u32> {
    todo!("Count of occurrences of words in {words:?}");
}
