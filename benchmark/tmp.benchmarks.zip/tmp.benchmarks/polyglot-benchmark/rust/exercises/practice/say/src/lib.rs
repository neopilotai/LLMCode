pub fn encode(n: u64) -> String {
    todo!("Say {n} in English.");
}
