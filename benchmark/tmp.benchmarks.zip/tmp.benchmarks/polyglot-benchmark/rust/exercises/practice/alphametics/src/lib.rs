use std::collections::HashMap;

pub fn solve(input: &str) -> Option<HashMap<char, u8>> {
    todo!("Solve the alphametic {input:?}")
}
