# Instructions append

To get the bonus tests to run, execute the tests with:

```bash
$ cargo test --features exponentials
```