pub fn answer(command: &str) -> Option<i32> {
    todo!("Return the result of the command '{command}' or None, if the command is invalid.");
}
